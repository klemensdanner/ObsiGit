-- Abfrage der Fl�ge mit Zwischenstopps
-- Verwendung von UNION, Pr�fen des Ausf�hrungsplans

SELECT Abflug, Ziel -- Direktfl�ge
  FROM Flug
 WHERE Abflug = 'Z�rich'
UNION               -- 2-Stopp-Fl�ge
SELECT F1.Abflug, F2.Ziel
  FROM Flug F1, Flug F2
 WHERE F1.Abflug = 'Z�rich'
   AND F1.Ziel = F2.Abflug
UNION             -- 3-Stopp-Fl�ge
SELECT F1.Abflug, F3.Ziel
  FROM Flug F1, Flug F2, Flug F3
 WHERE F1.Abflug = 'Z�rich'
   AND F1.Ziel = F2.Abflug
   AND F2.Ziel = F3.Abflug
UNION             -- 4-Stopp-Fl�ge
SELECT F1.Abflug, F4.Ziel
  FROM Flug F1, Flug F2, Flug F3, Flug F4
 WHERE F1.Abflug = 'Z�rich'
   AND F1.Ziel = F2.Abflug
   AND F2.Ziel = F3.Abflug
   AND F3.Ziel = F4.Abflug;
   
   
-- Vergleich mit hierarchischer Abfrage (Rekursion)
-- Welche Unterschiede sind im Ergebnis sichtbar?
-- Gibt es einen Unterschied im Ausf�hrungsplan?
SELECT Abflug, Ziel
  FROM Flug 
START WITH Abflug = 'Z�rich'
CONNECT BY PRIOR Ziel = Abflug;

-- Hinzuf�gen von neuen Daten - was passiert nun?
INSERT INTO flug VALUES ('NY111', 'New York', 'Z�rich', 1222);

-- Statement erneut ausf�hren
SELECT Abflug, Ziel
  FROM Flug 
START WITH Abflug = 'Z�rich'
CONNECT BY PRIOR Ziel = Abflug;

-- NOCYCLE erkennt Zyklen in Benutzerdaten und bricht bei der Ausf�hrung ab
-- Warum nicht immer NOCYCLE angeben? 
-- Je nach Daten kann ein Zyklus auf ein Problem in den Daten hinweisen (Dateninkonsistenz), 
-- je nach Anwendungsfall sind Zyklen erlaubt.
-- 
SELECT DISTINCT Abflug, Ziel, FLUGNR, CONNECT_BY_ISCYCLE
  FROM Flug
START WITH Abflug = 'Z�rich'
CONNECT BY NOCYCLE PRIOR Ziel = Abflug;
-- Der Zweck der Pseudospalte connect_by_iscycle besteht darin, 
-- den Wert 1 zur�ckzugeben, wenn die aktuelle Zeile ein untergeordnetes Element (Child) hat, 
-- das zugleich ihr Vorfahr (Ancestor) ist. Liegt keine solche Beziehung vor, 
-- gibt sie den Wert 0 zur�ck. Diese Information kann anschlie�end genutzt werden, 
-- um die Hierarchie weiter aufzuf�chern.


-- SYS_CONNECT_BY_PATH zeigt bei jedem Ergebnis den Pfad (= Stack) an, die Spalte CONNECT_BY_ISLEAF markiert die Bl�tter des rekusiven Baums
-- bei Flug NY111 (, Z�rich->Frankfurt, Frankfurt->Sydney, Sydney->New York, New York->Z�rich) muss der Zyklus nicht notwendigerweise vom Blatt ausgehen
SELECT DISTINCT Abflug, Ziel, FLUGNR, LEVEL, 
       SYS_CONNECT_BY_PATH(Abflug || '->' || Ziel, ', '), 
       CONNECT_BY_ISCYCLE, 
       CONNECT_BY_ISLEAF
  FROM Flug
START WITH Abflug = 'Z�rich'
CONNECT BY NOCYCLE PRIOR Ziel = Abflug;
