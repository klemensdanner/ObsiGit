# **SWJ3-Übungen - WS2026 - Übung 1**

## Wort-Leiter-Spiel – A\*-Algorithmus (`src/wordladder`)

Das Wort-Leiter-Spiel (Word Ladder) ist ein bekanntes und beliebtes Rätsel, bei
dem ein Startwort in ein Zielwort umgewandelt werden muss. Dabei darf bei jedem
Schritt genau ein Buchstabe geändert werden, und jedes Zwischenwort muss ein
gültiges Wort in einem vorgegebenen deutschen Wörterbuch sein. Ziel ist es, die
kürzeste Abfolge von Wörtern zu finden, mit der das Startwort in das Zielwort
überführt werden kann.

### Beispiel 1:

- **Startwort**: `Haus`
- **Zielwort**: `Maus`
- **Wörterbuch**: `{Haus, Maus, Laus, Lamm, Baum, Raum}`

**Lösung**:

- Kürzeste Sequenz: `Haus -> Maus`

### Beispiel 2:

- **Startwort**: `Hund`
- **Zielwort**: `Katz`
- **Wörterbuch**: `{Hund, Hand, Band, Sand, Kant, Katz}`

**Lösung**:

- Kürzeste Sequenz: `Hund -> Hand -> Kant -> Katz`

Eine Möglichkeit, dieses Problem zu lösen, ist Backtracking. Allerdings wird bei
Anwendung dieses Verfahrens der Suchraum sehr groß, was zu nicht vertretbaren
Rechenzeiten führt. Ein effizienter Algorithmus zur Lösung dieses Problems ist
der sogenannte A\*-Algorithmus, der von Peter Hart, Nils Nilsson und Bertram
Raphael bereits 1968 entwickelt wurde. Eine übersichtliche Darstellung des
Algorithmus findet man beispielsweise auf der englischsprachigen Wikipedia unter
[https://en.wikipedia.org/wiki/A*_search_algorithm](https://en.wikipedia.org/wiki/A*_search_algorithm).
Der A*-Algorithmus wird oft zur Wegsuche bei Routenplanern eingesetzt. Er ist
aber auch auf die hier angeführte Problemstellung anwendbar.

Der A*-Algorithmus enumeriert grundsätzlich auch alle möglichen
Lösungsvarianten, allerdings versucht er, zunächst den erfolgversprechendsten
Weg zum Ziel zu verfolgen. Erst dann werden weitere Varianten untersucht. Findet
der Algorithmus auf diese Weise bereits frühzeitig eine Lösung, müssen viele
Lösungsvarianten erst gar nicht evaluiert werden. Damit der Algorithmus beim
Durchwandern des Lösungsraums in die erfolgversprechendste Richtung weitergehen
kann, benötigt er eine Abschätzung der Kosten, die auf dem verbleibenden Weg zum
Ziel anfallen werden. In unserer Problemstellung kann für diese Kostenfunktion
`h(x)` die Hamming-Distanz (Anzahl der unterschiedlichen Buchstaben an denselben
Positionen) zwischen dem aktuellen Wort und dem Zielwort herangezogen werden.
Wenn `g(x)` die Kosten von der Ausgangskonfiguration bis zur Konfiguration `x`
bezeichnet, stellt `f(x) = g(x) + h(x)` eine Abschätzung der Kosten von der
Ausgangs- zur Zielkonfiguration dar, wobei der Weg zum Ziel über `x` verläuft.

## Vorgehensweise bei der Implementierung

Gehen Sie bei der Implementierung der Aufgabe testgetrieben vor. Implementieren
Sie die nachfolgend angeführten Klassen Methode für Methode und geben Sie für
jede Methode zumindest einen einfachen Testfall an. Erstellen Sie zunächst nur
den Methodenrumpf mit einer Standard-Implementierung, die nur syntaktisch
korrekt sein muss. Implementieren Sie dann für diese Methode die Unit-Tests,
deren Ausführung zunächst fehlschlagen wird. Erweitern Sie anschließend die
Implementierung der Methode so lange, bis alle Unit-Tests durchlaufen. Erst wenn
die Methoden-bezogenen Tests funktionieren, können Sie komplexere Tests
erstellen.

Eine Testsuite mit einigen Tests ist in der Projektvorlage bereits enthalten.
Erweitern Sie diese Testsuite so wie beschrieben. Ihre Implementierung muss die
vorgegebenen und die von Ihnen hinzugefügten Tests bestehen.

Die Implementierung des Algorithmus soll völlig unabhängig von einer konkreten
Anwendungsdomäne sein. Dies kann gewährleistet werden, indem die Implementierung
ausschließlich von den nachfolgend angeführten Interfaces `State` und
`Transition` abhängig ist. Mit Implementierungen dieser beiden Interfaces kann
ein Zustandsgraph definiert werden, in dem der A*-Algorithmus den optimalen Weg
vom Start- zum Zielknoten suchen kann. `State`-Objekte repräsentieren Zustände
im Graphen, die über `Transition`-Objekte miteinander verbunden sind.

<p style="text-align: center;">
  <img src="doc/states-and-transitions.png" alt="Search Nodes" width="500" />
</p>

```java
package swj3.astar;

// Repräsentiert den Zustand eines Knotens im Suchraum. Dieser ist über
// Transitionen mit seinen Nachbarzuständen verbunden. Auf diese Weise
// wird ein Zustandsgraph aufgespannt.
public interface State<S extends State<S, T>, T extends Transition<S>> {

  // Überprüft, ob dieser Zustand gleich dem Zustand other ist.
  @Override
  boolean equals(Object obj);

  // Notwendig für Verwendung in Hash-basierten Behältern.
  // Muss mit equals kompatibel sein:
  // state1.equals(state2) => state1.hashCode() == state2.hashCode()
  @Override
  int hashCode();

  // Liste der Zustandsüberführungen, mit denen man von diesem Zustand in
  // die unmittelbar anschließenden Zustände gelangt.
  List<T> transitions();

  // Retourniert den Knoten, der durch Anwendung der Zustandsüberführung
  // transition auf diesen Zustand entsteht.
  S apply(T transition);

  // Geschätzte Kosten zum Erreichen des Zielzustands. Werden diese immer
  // unterschätzt, ermittelt der A*-Algorithmus die minimale Lösung.
  double estimatedCostsToTarget(S targetState);
}
```

```java
package swj3.astar;

// Repräsentation einer Zustandsüberführung. Jeder Zustand hält eine Liste
// von Transitionen, über die man zu den Nachbarzuständen gelangen kann.
public interface Transition<S extends State<S, ? extends Transition<S>>> {
  // Tatsächliche Kosten für diese Zustandsüberführung
  double costs();
}
```

### 1.1 Generische Implementierung des A*-Algorithmus

#### Hilfsdatenstruktur `SearchNode`

Zur Implementierung des A*-Algorithmus benötigen Sie die Hilfsklasse
`SearchNode`. Damit kann man den Weg von einem `SearchNode` zum Startknoten
zurückverfolgen, da dieser mit seinem Vorgängerknoten verkettet ist. Ein
`SearchNode` kennt die Kosten vom Startknoten bis zu ihm selbst. Ein
`SearchNode` kann auch eine Schätzung für den Weg zum Zielknoten und damit eine
Schätzung für die Gesamtkosten vom Start- bis zum Zielknoten berechnen.

<p style="text-align: center;">
  <img src="doc/search-nodes.png" alt="Search Nodes" width="500"/>
</p>

```java
package swj3.astar;

// SearchNode ist eine Hilfsklasse, die zur Implementierung des A*-Algorithmus 
// benötigt wird. Damit kann man den Weg von einem SearchNode zum Startknoten
// zurückverfolgen, da dieser mit seinem Vorgängerknoten verkettet ist. Ein
// SearchNode kennt die Kosten vom Startknoten bis zu ihm selbst. SearchNode
// kann auch eine Schätzung für den Weg zum Zielknoten berechnen.
public class SearchNode<S extends State<S, T>, T extends Transition<S>> implements Comparable<SearchNode<S, T>> {

  // Suchknoten mit dem Zustand state und dem Zielzustand target initialisieren.
  // Es existiert kein Vorgängerknoten.
  public SearchNode(S state, S targetState) {
    throw new UnsupportedOperationException();
  }

  // Suchknoten mit dem Zustand state und dem Zielzustand target initialisieren.
  // predecessor ist der Vorgängerknoten, von dessen Zustand man mit transition
  // zum Zustand dieses Knotens kommt.
  public SearchNode(S state, S targetState, SearchNode<S, T> predecessor, T transition) {
    throw new UnsupportedOperationException();
  }

  // Gibt den Zustand dieses Knotens zurück.
  public S getState() { throw new UnsupportedOperationException(); }

  // Gibt den Vorgängerknoten zurück.
  public SearchNode<S, T> getPredecessor() { throw new UnsupportedOperationException(); }

  // Setzt den Vorgängerknoten.
  public SearchNode<S, T> setPredecessor(SearchNode<S, T> predecessor) {
    throw new UnsupportedOperationException();
  }

  // Gibt Transition zurück, die Vorgängerknoten in diesen Knoten überführt.
  public T getTransition() {
    throw new UnsupportedOperationException();
  }

  // Setzt Transition, die Vorgängerknoten in diesen Knoten überführt.
  public void setTransition(T transition) {
    throw new UnsupportedOperationException();
  }

  // Gibt Kosten vom Startknoten bis zu diesem Knoten zurück.
  public double costsFromStart() {
    throw new UnsupportedOperationException();
  }

  // Setzt die Kosten vom Startknoten bis zu diesem Knoten.
  public void setCostsFromStart(double costsFromStart) {
    throw new UnsupportedOperationException();
  }

  // Gibt geschätzte Kosten von diesem Knoten bis zum Zielknoten zurück.
  public double estimatedCostsToTarget() {
    throw new UnsupportedOperationException();
  }

  // Gibt Schätzung der Kosten vom Startknoten über diesen Knoten bis zum
  // Zielknoten zurück (= Kosten bis zu diesem Knoten + geschätzte Kosten
  // bis zum Zielknoten).
  public double estimatedTotalCosts() {
    throw new UnsupportedOperationException();
  }

  // Gibt zurück, ob dieser Knoten und der Knoten other denselben Zustand
  // repräsentieren.
  // Vorsicht: Enthaltenen Zustand per Wert, vergleichen, nicht die Referenzen.
  // Muss konsistent mit compareTo implementiert werden:
  // a.equals(b) <==> a.compareTo(b) == 0.
  @Override
  public boolean equals(Object obj) { throw new UnsupportedOperationException(); }

  // Notwendig für Verwendung in Hash-basierten Behältern. Muss konsistent
  // mit equals implementiert werden: a.equals(b) => a.hashCode() == b.hashCode.
  @Override
  public int hashCode() {
    throw new UnsupportedOperationException();
  }

  // Vergleicht zwei Knoten auf Basis der geschätzten Gesamtkosten.
  // <0: Kosten dieses Knotens sind kleiner oder gleich als die Kosten von other.
  //  0: Dieser Knoten und other sind gleich (referenzieren denselben Zustand).
  // >0: Kosten dieses Knotens sind höher als Kosten von other.
  @Override
  public int compareTo(SearchNode<S, T> other) { throw new UnsupportedOperationException(); }

  // Konvertiert die Knotenliste, die bei diesem Knoten ihren Ausgang hat,
  // in eine Liste von Transitionen. Da der Weg in umgekehrter Reihenfolge
  // gespeichert ist, muss die Transitionsliste invertiert werden.
  public List<T> getTransitionsFromStart() { throw new UnsupportedOperationException(); }

  @Override
  public String toString() { throw new UnsupportedOperationException(); }
}
```

#### A*-Algorithmus

Implementieren Sie darauf aufbauend den A*-Algorithmus in der Klasse
`AStarSolver`. Verwenden Sie bei Ihrer Lösung so weit wie möglich die
Behälterklassen des JDK. Setzen Sie insbesondere bei der Implementierung des
A*-Algorithmus eine Prioritätswarteschlange (`PriorityQueue`), für die
Speicherung der Liste der offenen Knoten eine sortierte Menge (`Set`) und für
die Zuordnung von Zuständen zu Suchknoten einen assoziativen Behälter (`Map`)
ein.

```java
package swj3.astar;

public class AStarSolver<S extends State<S, T>, T extends Transition<S>> {

  // Berechnet eine kostenoptimale Folge von Transitionen, welche den gegebenen
  // Anfangszustand initialState in den Zielzustand targetState überführt.
  // Wirft NoSolutionException (Checked Exception), falls es keine derartige
  // Folge von Transitionen gibt.
  public List<T> solve(S initialState, S targetState) throws NoSolutionException {
    throw new UnsupportedOperationException();
  }
}
```

### 1.2 Implementierung des Wort-Leiter-Spiels

Entwickeln Sie auf Basis der generischen Implementierung des A*-Algorithmus eine
einfache Lösung für das Wort-Leiter-Spiel. Implementieren Sie dazu die folgenden
Klassen:

- `Word`: Repräsentiert ein Wort als Zustand im Suchraum.
- `WordTransition`: Repräsentiert einen Übergang zwischen zwei Wörtern und damit
  eine einzelne Stufe der Wortleiter.
- `WordDictionary`: Stellt die Schnittstelle zu einem Wörterbuch dar, mit dem
  überprüft werden kann, ob ein Wort existiert und was die Nachbarn eines Wortes
  sind.
- `SimpleWordDictionary`: Realisiert eine einfache Implementierung eines
  Wörterbuchs. Die Wörter werden in einem Behälter gespeichert, welcher es
  ermöglicht, schnell zu überprüfen, ob ein Wort gültig ist. Zur Ermittlung der
  Nachbarn eines Wortes wird das gesamte Wörterbuch nach Wörtern durchsucht, die
  sich nur in einem Buchstaben von diesem Wort unterscheiden, also eine
  Hamming-Distanz von 1 zum gegebenen Wort haben. Die auf diese Weise gefundenen
  Wörter sind mögliche Kandidaten für `WordTransition`-Ziele.
- `WordLadder`: Enthält das Hauptprogramm und verwendet den A*-Solver, um
  Wortleitern zumindest für folgende Wortpaare zur ermitteln:
    + Haus -> Maus
    + Hund -> Katz
    + und -> bis
    + Apfel -> Birne
    + Haut -> Zahl
    + Auto -> Buch
    + essen -> leben

Machen Sie auch bei der Implementierung des Wort-Leiter-Spiels möglichst
umfassend von der JDK-Behälterbibliothek Gebrauch.

### Hinweise zum Einlesen des Wörterbuchs

Verwenden Sie das [deutsche Hunspell-Wörterbuch aus
`wooorm/dictionaries`](https://github.com/wooorm/dictionaries/tree/main/dictionaries/de).
Laden Sie das Wörterbuch herunter und kopieren Sie die Datei mit der Erweiterung
`.dic` in das Verzeichnis `src/main/resources`.

Verwenden Sie zum Einlesen der Wortliste das Interface `WordSource` und die
Klasse `HunspellWordSource`. Die Implementierung dieser beiden Typen steht Ihnen
in Ihrem Repository bereits zur Verfügung.

### Behälterklassen und Laufzeitverhalten

Geben Sie in Ihrer Dokumentation an, welche Behälterklassen Sie verwendet haben.
Begründen Sie Ihre Auswahl und erläutern Sie, wie sich diese auf das
Laufzeitverhalten der wesentlichen Bestandteile Ihrer Lösung auswirken
(A*-Algorithmus, Aufbau des Wörterbuchs, Prüfung, ob ein Wort vorhanden ist,
Nachbarschaftssuche usw.).

### Optionale Verbesserung der Nachbarschaftssuche

Besonders Interessierte können folgende Variante des Wörterbuchs
(`AdvancedWordDictionary`) implementieren, welche die Nachbarschaftssuche
wesentlich verbessert. Bauen Sie dazu eine Map auf, die zu einem vorgegebenen
Muster alle übereinstimmenden Wörter speichert. Diese Map enthält also Einträge
der Form `?aus -> {Haus, Maus}`, `b?ld -> {bald, Bild}`. Mithilfe dieser Map
kann man alle Nachbarn eines Worts in konstanter Zeit ermitteln.

### Hinweise zum Testen

Geben Sie dem Testen in dieser Übung einen besonderen Stellenwert. Im Zuge der
Review müssen Sie Ihre Testsuite auch auf die Implementierung Ihres
Review-Partners anwenden. Halten Sie sich daher auch genau an die vorgegebenen
Schnittstellen. Die Höhe der Erfüllungsgrads für den Teilbereich Testen hängt
primär vom Umfang und von der Qualität der von Ihnen selbst entwickelten
Unit-Tests ab.