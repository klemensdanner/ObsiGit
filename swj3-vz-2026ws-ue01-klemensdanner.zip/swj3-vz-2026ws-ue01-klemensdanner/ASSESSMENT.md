# **Übung 1 - Erfüllungsgrad**

Nachname und Vorname: Sorglos Susi

Aufwand [Stunden]:    0.0

## **Erfüllungsgrad**

| Beispiel  | Gewichtung  | Lösungsidee (15%) | Implement. (70%) | Testen (15%)    |
| --------- | :---------: | :---------------: | :--------------: | :-------------: |
| 1.1       | 50          | 0                 | 0                | 0               |
| 1.2       | 50          | 0                 | 0                | 0               |
