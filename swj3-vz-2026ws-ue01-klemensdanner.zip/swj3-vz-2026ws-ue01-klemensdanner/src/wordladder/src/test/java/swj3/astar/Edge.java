package swj3.astar;

import swj3.astar.Transition;

final class Edge implements Transition<Vertex> {
  private final Vertex to;
  private final double costs;

  Edge(Vertex to, double costs) { this.to    = to;
                                  this.costs = costs;
                                }

  Vertex getTo()                { return to; }

  @Override
  public double costs()         { return costs; }
}
