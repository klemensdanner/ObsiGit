package swj3.astar;

import swj3.astar.State;

import java.util.ArrayList;
import java.util.List;

final class Vertex implements State<Vertex, Edge> {
  private final int        id;
  private final double     heuristic;
  private final List<Edge> edges = new ArrayList<>();

  Vertex(int id, double heuristic)                    {
                                                        this.id        = id;
                                                        this.heuristic = heuristic;
                                                      }

  @Override
  public List<Edge> transitions()                     { return edges; }

  void addEdge(Edge edge)                             { edges.add(edge); }

  @Override
  public Vertex apply(Edge edge)                      { return edge.getTo(); }

  @Override
  public double estimatedCostsToTarget(Vertex target) { return heuristic; }

  @Override
  public int hashCode()                               { return id; }

  @Override
  public boolean equals(Object other)                 { return other instanceof Vertex v && id == v.id; }
}
