package swj3.astar;

import org.junit.jupiter.api.Test;
import swj3.astar.AStarSolver;
import swj3.astar.NoSolutionException;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AStarSolverTest {
  private final AStarSolver<Vertex, Edge> solver = new AStarSolver<>();

  @Test
  void sameStateReturnsEmptyPath() throws Exception {
    Vertex v = new Vertex(1, 0);
    assertTrue(solver.solve(v, v).isEmpty());
  }

  @Test
  void findsOneTransition() throws Exception {
    Vertex a = new Vertex(1, 1), b = new Vertex(2, 0);
    a.addEdge(new Edge(b, 1));
    List<Edge> path = solver.solve(a, b);
    assertEquals(1, path.size());
    assertEquals(b, a.apply(path.get(0)));
  }

  @Test
  void disconnectedStatesThrow() {
    assertThrows(NoSolutionException.class, () -> solver.solve(new Vertex(1, 1), new Vertex(2, 0)));
  }

  @Test
  void choosesCheapestParallelTransition() throws Exception {
    Vertex a      = new Vertex(1, 1), b = new Vertex(2, 0);
    Edge   costly = new Edge(b, 3), cheap = new Edge(b, 2);
    a.addEdge(costly);
    a.addEdge(cheap);
    assertSame(cheap, solver.solve(a, b).get(0));
  }

  @Test
  void choosesCheaperTrianglePath() throws Exception {
    Vertex a  = new Vertex(1, 8), b = new Vertex(2, 5), c = new Vertex(3, 0);
    Edge   ab = new Edge(b, 3), bc = new Edge(c, 4);
    a.addEdge(new Edge(c, 10));
    a.addEdge(ab);
    b.addEdge(bc);
    assertEquals(List.of(ab, bc), solver.solve(a, c));
  }

  @Test
  void choosesDirectPathWhenItIsCheaper() throws Exception {
    Vertex a      = new Vertex(1, 8), b = new Vertex(2, 5), c = new Vertex(3, 0);
    Edge   direct = new Edge(c, 10);
    a.addEdge(direct);
    a.addEdge(new Edge(b, 6));
    b.addEdge(new Edge(c, 7));
    assertEquals(List.of(direct), solver.solve(a, c));
  }

  @Test
  void findsOptimalPathInQuadrangle() throws Exception {
    Vertex a  = new Vertex(1, 8), b = new Vertex(2, 4), c = new Vertex(3, 5), d = new Vertex(4, 0);
    Edge   ac = new Edge(c, 4), cb = new Edge(b, 1), bd = new Edge(d, 5);
    a.addEdge(new Edge(b, 6));
    a.addEdge(ac);
    c.addEdge(cb);
    b.addEdge(bd);
    c.addEdge(new Edge(d, 8));
    assertEquals(List.of(ac, cb, bd), solver.solve(a, d));
  }
}
