package swj3.astar;

import org.junit.jupiter.api.Test;
import swj3.astar.SearchNode;

import static org.junit.jupiter.api.Assertions.*;

class SearchNodeTest {
  @Test
  void initialNodeHasStateAndNoPredecessorOrTransition() {
    Vertex                   v = new Vertex(1, 10);
    SearchNode<Vertex, Edge> n = new SearchNode<>(v, v);
    assertSame(v, n.getState());
    assertNull(n.getPredecessor());
    assertNull(n.getTransition());
  }

  @Test
  void childNodeStoresLinksAndAccumulatesCosts() {
    Vertex                   a    = new Vertex(1, 10), b = new Vertex(2, 10);
    Edge                     edge = new Edge(b, 15);
    SearchNode<Vertex, Edge> root = new SearchNode<>(a, b), child = new SearchNode<>(b, b, root, edge);
    assertSame(root, child.getPredecessor());
    assertSame(edge, child.getTransition());
    assertEquals(15, child.costsFromStart());
    assertEquals(10, child.estimatedCostsToTarget());
    assertEquals(25, child.estimatedTotalCosts());
  }

  @Test
  void comparesByEstimatedTotalCost() {
    Vertex a  = new Vertex(1, 20), b = new Vertex(2, 10), c = new Vertex(3, 0);
    Edge   ab = new Edge(b, 10), ac = new Edge(c, 15);
    a.addEdge(ab);
    a.addEdge(ac);
    SearchNode<Vertex, Edge> root = new SearchNode<>(a, c);
    SearchNode<Vertex, Edge> viaB = new SearchNode<>(b, c, root, ab), viaC = new SearchNode<>(c, c, root, ac);
    assertTrue(viaB.compareTo(viaC) > 0);
  }

  @Test
  void equalityAndHashCodeUseState() {
    Vertex                   v   = new Vertex(1, 10), target = new Vertex(2, 0);
    SearchNode<Vertex, Edge> one = new SearchNode<>(v, target), two = new SearchNode<>(v, target);
    assertEquals(one, two);
    assertEquals(one.hashCode(), two.hashCode());
  }
}
