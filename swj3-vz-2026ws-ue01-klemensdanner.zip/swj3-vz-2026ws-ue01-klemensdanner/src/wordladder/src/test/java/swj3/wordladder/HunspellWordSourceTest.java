package swj3.wordladder;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class HunspellWordSourceTest {
  @Test
  void readsHeaderWordsAndRemovesAffixFlags() throws Exception {
    String dictionary = """
      3
      bla, bla
      bla, bla
      
      Haus
      Maus/S
      Straße/AB
      """;

    assertEquals(List.of("Haus", "Maus", "Straße"),
      new HunspellWordSource(
        new ByteArrayInputStream(dictionary.getBytes(StandardCharsets.UTF_8))).readWords());
  }
}
