package swj3.astar;

import java.util.List;

public class AStarSolver<S extends State<S, T>, T extends Transition<S>>  {

  // Berechnet eine kostenoptimale Folge von Transitionen, welche den gegebenen
  // Anfangszustand initialState in den Zielzustand targetState überführt.
  // Wirft NoSolutionException (Checked Exception), falls es keine derartige
  // Folge von Transitionen gibt.
  public List<T> solve(S initialState, S targetState) throws NoSolutionException {
    throw new UnsupportedOperationException();
  }
}
