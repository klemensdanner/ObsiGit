package swj3.astar;

// Repräsentation einer Zustandsüberführung. Jeder Zustand hält eine Liste
// von Transitionen, über die man zu den Nachbarzuständen gelangen kann.
public interface Transition<S extends State<S, ? extends Transition<S>>> {
  // Tatsächliche Kosten für diese Zustandsüberführung
  double costs();
}
