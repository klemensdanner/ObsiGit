package swj3.wordladder;

import java.io.IOException;
import java.util.List;

// Liest Wörter von einer beliebigen Quelle (File, Speicher, Datenbank etc.)
// ein.
public interface WordSource {
  List<String> readWords() throws IOException;
}
