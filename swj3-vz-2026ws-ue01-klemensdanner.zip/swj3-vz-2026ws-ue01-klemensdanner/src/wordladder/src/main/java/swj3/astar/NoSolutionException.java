package swj3.astar;

@SuppressWarnings("serial")
public class NoSolutionException extends Exception {

}
