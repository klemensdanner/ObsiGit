package swj3.wordladder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

//
// Liest alle Wörter aus einem Hunspell-File (.dic) aus.
//
public final class HunspellWordSource implements WordSource {
  private final Path path;
  private final InputStream input;

  public HunspellWordSource(Path path) {
    this.path = Objects.requireNonNull(path, "path");
    this.input = null;
  }

  public HunspellWordSource(InputStream input) {
    this.path = null;
    this.input = Objects.requireNonNull(input, "input");
  }

  @Override
  public List<String> readWords() throws IOException {
    List<String> entries = new ArrayList<>();
    InputStream source = input != null ? input : Files.newInputStream(path);

    try (BufferedReader reader = new BufferedReader(new InputStreamReader(source, StandardCharsets.UTF_8))) {
      String line = reader.readLine(); // ignore first line
      if (line == null) return List.of();

      while ((line = reader.readLine()) != null) {
        if (line.isEmpty() || Character.isWhitespace(line.charAt(0))) continue;

        String candidate = line.trim();
        if (candidate.isEmpty()
          || candidate.startsWith("#")
          || candidate.chars().anyMatch(Character::isWhitespace)) continue;

        int slash = candidate.indexOf('/');
        if (slash >= 0) candidate = candidate.substring(0, slash);
        candidate = candidate.trim();
        if (!candidate.isEmpty()) entries.add(candidate);
      }
    }

    return entries;
  }
}
