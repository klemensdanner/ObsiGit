# **Übung 1 - Ausarbeitung**

## **Wort-Leiter-Spiel**

### **Lösungsidee**

### **Testfälle**
